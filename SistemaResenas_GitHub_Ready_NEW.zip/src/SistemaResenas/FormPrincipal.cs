using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SistemaResenas
{
    public partial class FormPrincipal : Form
    {
        private List<Restaurante> restaurantes;

        public FormPrincipal()
        {
            InitializeComponent();
            CargarDatos();
            MostrarRestaurantes(restaurantes);
        }

        private void CargarDatos()
        {
            restaurantes = new List<Restaurante>
            {
                new Restaurante("La Casa del Sabor", "Comida Criolla", "$$", "imagenes/plato1.png"),
                new Restaurante("Pasta Bella", "Italiana", "$$$", "imagenes/plato2.png"),
                new Restaurante("Sushi World", "Japonesa", "$$$", "imagenes/plato3.png"),
                new Restaurante("Burger King Local", "Rápida", "$", "imagenes/plato4.png")
            };
        }

        private void MostrarRestaurantes(List<Restaurante> lista)
        {
            listBoxRestaurantes.Items.Clear();
            foreach (var r in lista)
                listBoxRestaurantes.Items.Add(r);
        }

        private void btnVerDetalles_Click(object sender, EventArgs e)
        {
            if (listBoxRestaurantes.SelectedItem is Restaurante seleccionado)
            {
                FormDetallesRestaurante frm = new FormDetallesRestaurante(seleccionado);
                frm.ShowDialog();
            }
        }
    }
}
