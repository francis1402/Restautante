namespace SistemaResenas
{
    public class Resena
    {
        public string Usuario { get; set; }
        public int Calificacion { get; set; }
        public string Comentario { get; set; }
        public string Imagen { get; set; }

        public Resena(string usuario, int calificacion, string comentario, string imagen)
        {
            Usuario = usuario;
            Calificacion = calificacion;
            Comentario = comentario;
            Imagen = imagen;
        }

        public override string ToString() => $"{Usuario} - {Calificacion} estrellas: {Comentario}";
    }
}
