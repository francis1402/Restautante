using System.Collections.Generic;

namespace SistemaResenas
{
    public class Restaurante
    {
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public string Presupuesto { get; set; }
        public string Imagen { get; set; }
        public List<Resena> Resenas { get; set; }

        public Restaurante(string nombre, string tipo, string presupuesto, string imagen)
        {
            Nombre = nombre;
            Tipo = tipo;
            Presupuesto = presupuesto;
            Imagen = imagen;
            Resenas = new List<Resena>();
        }

        public override string ToString() => $"{Nombre} - {Tipo} ({Presupuesto})";
    }
}
