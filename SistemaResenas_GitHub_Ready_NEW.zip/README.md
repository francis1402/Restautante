# Sistema de Reseñas de Restaurantes

Proyecto en **C# WinForms (.NET 8)** para simular un sistema de reseñas de restaurantes locales.

## Características
- Lista de restaurantes con tipo de comida y presupuesto.
- Visualización de reseñas con calificación y comentario.
- Opción de agregar nuevas reseñas con foto de plato.
- Sin base de datos (datos cargados en memoria).

## Cómo ejecutar
1. Abre `src/SistemaResenas/SistemaResenas.sln` en Visual Studio 2022 o superior.
2. Presiona **F5** para ejecutar.
3. Reemplaza las imágenes en `imagenes/` con fotos de platos reales si lo deseas.

## Licencia
Este proyecto está bajo licencia MIT.
