
namespace GastroConnect.Models;

public static class Seed
{
    public static void EnsureSeed(AppDbContext db)
    {
        if (db.Restaurants.Any()) return;

        var now = DateTime.Now;

        var r1 = new Restaurant{
            Name = "La Terraza Colonial",
            Cuisine = "Dominicana",
            Price = "$$",
            Area = "Zona Colonial",
            Photo = "https://images.unsplash.com/photo-1604908553868-9b19d2d9e6e3?q=80&w=1400&auto=format&fit=crop",
            Reviews = new List<Review>{
                new Review{ User="María", Rating=5, Comment="Excelente sazón y servicio rápido.", CreatedAt= now.AddDays(-4)},
                new Review{ User="Luis", Rating=4, Comment="Buen mofongo, ambiente acogedor.", CreatedAt= now.AddDays(-2)}
            }
        };
        var r2 = new Restaurant{
            Name = "Trattoria Bella Vita",
            Cuisine = "Italiana",
            Price = "$$",
            Area = "Piantini",
            Photo = "https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1400&auto=format&fit=crop",
            Reviews = new List<Review>{ new Review{ User="Carla", Rating=5, Comment="La pasta al dente perfecta.", CreatedAt= now.AddDays(-6)} }
        };
        var r3 = new Restaurant{
            Name = "Sakura Nikkei",
            Cuisine = "Japonesa",
            Price = "$$$",
            Area = "Naco",
            Photo = "https://images.unsplash.com/photo-1553621042-f6e147245754?q=80&w=1400&auto=format&fit=crop",
            Reviews = new List<Review>{ new Review{ User="Diego", Rating=4, Comment="Sushi fresco; un poco caro.", CreatedAt= now.AddDays(-9)} }
        };
        var r4 = new Restaurant{
            Name = "Taquería El Barrio",
            Cuisine = "Mexicana",
            Price = "$",
            Area = "Gazcue",
            Photo = "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?q=80&w=1400&auto=format&fit=crop"
        };
        var r5 = new Restaurant{
            Name = "Green Bowl",
            Cuisine = "Vegana",
            Price = "$$",
            Area = "Arroyo Hondo",
            Photo = "https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=1400&auto=format&fit=crop",
            Reviews = new List<Review>{ new Review{ User="Ana", Rating=5, Comment="Opciones veganas creativas y sabrosas.", CreatedAt= now.AddDays(-1)} }
        };
        var r6 = new Restaurant{
            Name = "Mercado Urbano",
            Cuisine = "Internacional",
            Price = "$$",
            Area = "Bella Vista",
            Photo = "https://images.unsplash.com/photo-1541542684-4a6e6202bdc0?q=80&w=1400&auto=format&fit=crop"
        };

        db.Restaurants.AddRange(r1,r2,r3,r4,r5,r6);
        db.SaveChanges();
    }
}
