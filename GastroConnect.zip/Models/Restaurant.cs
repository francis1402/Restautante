
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GastroConnect.Models;

public class Restaurant
{
    public int Id { get; set; }

    [Required]
    public string Name { get; set; } = string.Empty;

    public string Cuisine { get; set; } = string.Empty;
    public string Price { get; set; } = string.Empty;
    public string Area { get; set; } = string.Empty;
    public string Photo { get; set; } = string.Empty;

    public ICollection<Review> Reviews { get; set; } = new List<Review>();
}
