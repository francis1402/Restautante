
using System;
using System.ComponentModel.DataAnnotations;

namespace GastroConnect.Models;

public class Review
{
    public int Id { get; set; }

    [Required]
    public string User { get; set; } = string.Empty;

    [Range(1,5)]
    public int Rating { get; set; }

    [Required]
    public string Comment { get; set; } = string.Empty;

    public string? Photo { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public int RestaurantId { get; set; }
    public Restaurant? Restaurant { get; set; }
}
