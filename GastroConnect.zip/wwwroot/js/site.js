// JS opcional para mejoras futuras
