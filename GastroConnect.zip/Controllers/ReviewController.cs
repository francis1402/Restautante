
using Microsoft.AspNetCore.Mvc;
using GastroConnect.Models;

namespace GastroConnect.Controllers;

public class ReviewController : Controller
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _env;

    public ReviewController(AppDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(int restaurantId, string user, int rating, string comment, IFormFile? photo)
    {
        var restaurant = await _context.Restaurants.FindAsync(restaurantId);
        if (restaurant == null) return NotFound();

        string? photoPath = null;
        if (photo != null && photo.Length > 0)
        {
            var uploads = Path.Combine(_env.WebRootPath, "uploads");
            Directory.CreateDirectory(uploads);
            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(photo.FileName)}";
            var path = Path.Combine(uploads, fileName);
            using var stream = new FileStream(path, FileMode.Create);
            await photo.CopyToAsync(stream);
            photoPath = $"/uploads/{fileName}";
        }

        var review = new Review
        {
            RestaurantId = restaurantId,
            User = user,
            Rating = rating,
            Comment = comment,
            Photo = photoPath,
            CreatedAt = DateTime.Now
        };

        _context.Reviews.Add(review);
        await _context.SaveChangesAsync();

        return RedirectToAction("Details", "Restaurant", new { id = restaurantId });
    }
}
