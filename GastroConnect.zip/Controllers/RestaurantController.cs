
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GastroConnect.Models;

namespace GastroConnect.Controllers;

public class RestaurantController : Controller
{
    private readonly AppDbContext _context;

    public RestaurantController(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index(string? q, string? cuisine, string? price, string? sortBy)
    {
        var restaurants = _context.Restaurants.Include(r => r.Reviews).AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
            restaurants = restaurants.Where(r => r.Name.Contains(q) || r.Area.Contains(q) || r.Cuisine.Contains(q));

        if (!string.IsNullOrWhiteSpace(cuisine))
            restaurants = restaurants.Where(r => r.Cuisine == cuisine);

        if (!string.IsNullOrWhiteSpace(price))
            restaurants = restaurants.Where(r => r.Price == price);

        restaurants = (sortBy) switch
        {
            "reviews" => restaurants.OrderByDescending(r => r.Reviews.Count),
            "name" => restaurants.OrderBy(r => r.Name),
            _ => restaurants.OrderByDescending(r => r.Reviews.Any() ? r.Reviews.Average(rv => rv.Rating) : 0)
        };

        ViewData["q"] = q;
        ViewData["cuisine"] = cuisine;
        ViewData["price"] = price;
        ViewData["sortBy"] = sortBy ?? "rating";

        return View(await restaurants.ToListAsync());
    }

    public async Task<IActionResult> Details(int id)
    {
        var restaurant = await _context.Restaurants
            .Include(r => r.Reviews)
            .FirstOrDefaultAsync(m => m.Id == id);
        if (restaurant == null) return NotFound();
        return View(restaurant);
    }
}
